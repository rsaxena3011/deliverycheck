# Dependencies and assets

DeliveryCheck uses the Python standard library for its local app. The Windows launcher downloads the following official runtimes on first launch and verifies each archive before extraction:

- Python 3.13.16 embeddable package: https://www.python.org/ftp/python/3.13.16/python-3.13.16-embed-amd64.zip
- FFmpeg 8.1.2 essentials build: https://www.gyan.dev/ffmpeg/builds/packages/ffmpeg-8.1.2-essentials_build.zip

The private runtimes are installed per user under the DeliveryCheck folder in LocalAppData. They are not added to the system PATH. The launcher keeps each publisher archive URL and SHA256 value in its native source.

Python licensing information is included with the official Python archive. FFmpeg is distributed by its publisher as a GPL build. See https://ffmpeg.org/legal.html and the corresponding FFmpeg source and license information from the publisher.

The demo clips were generated from FFmpeg synthetic test patterns and a generated sine wave for functional QA. They are not example advertising creatives. Interface artwork is native HTML and CSS. No stock footage, music, third-party photographs or brand assets are included.
