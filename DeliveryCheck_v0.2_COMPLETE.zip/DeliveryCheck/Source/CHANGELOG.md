# 0.2.0

- Added a one-screen workflow with visible New project, Upload videos, Add a folder and Run check actions.
- Added a New project reset flow that clears staged files and results without touching originals.
- Added an in-app close action and local session handoff for the automatic Windows launcher.
- Added a Windows x64 launcher that installs private, checksum-verified Python and FFmpeg runtimes on first launch.
- Added folder upload, a clearer optional delivery-list path and advanced settings separated from the main flow.
- Updated the guide, README, screenshots and release contents for the one-click buyer ZIP.
- Audited the launcher: responsive setup, download progress, cancel, retry, logs, runtime repair, authenticated session reuse and a single browser launch.
- Fixed Windows text decoding, restored files and scan results after a browser reload, and reset stale scan status on New project.
- Added actual viewport, folder upload, session restore and server shutdown checks.

# 0.1.0

Initial working local build with batch import, delivery-list checks, picture and audio alerts, review decisions, reports and generated test videos.
