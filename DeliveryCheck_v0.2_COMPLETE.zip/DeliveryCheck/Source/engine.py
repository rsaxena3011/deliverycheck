"""DeliveryCheck: local, deterministic media checks. Python standard library only."""
from __future__ import annotations

import copy
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import threading
import time

VERSION = '0.2.0'
EXTENSIONS = {'.mp4', '.mov', '.mkv', '.webm', '.m4v', '.avi', '.mxf', '.mpg', '.mpeg'}
DEFAULTS = {
    'black_seconds': 0.08, 'freeze_seconds': 1.0, 'silence_seconds': 0.75,
    'silence_db': -50.0, 'duration_tolerance': 0.25, 'fps_tolerance': 0.05,
    'max_peak_db': -1.0, 'loudness_target': None, 'loudness_tolerance': 2.0,
}


class Cancelled(Exception):
    pass


def binary(name):
    suffix = '.exe' if os.name == 'nt' else ''
    private = os.environ.get('DELIVERYCHECK_FFMPEG_DIR')
    if private:
        candidate = Path(private) / (name + suffix)
        return str(candidate) if candidate.is_file() else None
    local = Path(__file__).parent / 'bin' / (name + suffix)
    return str(local) if local.exists() else shutil.which(name)


def tool_status():
    result = {}
    for name in ('ffmpeg', 'ffprobe'):
        path = binary(name)
        if not path:
            result[name] = None
            continue
        try:
            p = subprocess.run([path, '-version'], capture_output=True, text=True, timeout=10,
                               **process_options())
            result[name] = p.stdout.splitlines()[0] if p.returncode == 0 else None
        except (OSError, subprocess.SubprocessError):
            result[name] = None
    result['ready'] = all(result.get(x) for x in ('ffmpeg', 'ffprobe'))
    return result


def process_options():
    return {'creationflags': subprocess.CREATE_NO_WINDOW} if os.name == 'nt' else {}


def number(value, default=0):
    try:
        n = float(value)
        return n if math.isfinite(n) else default
    except (TypeError, ValueError):
        return default


def rate(value):
    try:
        a, b = str(value).split('/')
        return float(a) / float(b) if float(b) else 0
    except (ValueError, ZeroDivisionError):
        return number(value)


def validate_config(data):
    if not isinstance(data, dict):
        raise ValueError('The project must be a JSON object.')
    project = str(data.get('project', 'Untitled delivery')).strip()[:160] or 'Untitled delivery'
    manifest = data.get('manifest', [])
    if not isinstance(manifest, list) or len(manifest) > 500:
        raise ValueError('Use a delivery list with at most 500 rows.')
    rows, names = [], set()
    for row in manifest:
        if not isinstance(row, dict):
            raise ValueError('Every delivery row must be an object.')
        name = str(row.get('filename', '')).strip()
        if not name or len(name) > 240 or '/' in name or '\\' in name or name in ('.', '..'):
            raise ValueError('Each delivery needs a filename, without a folder path.')
        if name.casefold() in names:
            raise ValueError('Delivery filenames must be unique: ' + name)
        names.add(name.casefold())
        clean = {'filename': name, 'audio_required': bool(row.get('audio_required', True)),
                 'codec': str(row.get('codec', '')).strip().lower()[:30],
                 'language': str(row.get('language', '')).strip()[:50]}
        for key, lo, hi in [('width', 1, 16384), ('height', 1, 16384),
                            ('duration', 0.01, 86400), ('fps', 0.1, 1000)]:
            val = row.get(key)
            if val is None or val == '':
                clean[key] = None
            else:
                val = number(val, None)
                if val is None or not lo <= val <= hi:
                    raise ValueError(f'Invalid {key} for {name}.')
                if key in ('width', 'height') and val != int(val):
                    raise ValueError('Dimensions must be whole pixels.')
                clean[key] = val
        rows.append(clean)
    settings = dict(DEFAULTS)
    raw_settings = data.get('settings', {})
    if not isinstance(raw_settings, dict):
        raise ValueError('Check settings must be an object.')
    bounds = {'black_seconds': (0.01, 10), 'freeze_seconds': (0.1, 60),
              'silence_seconds': (0.1, 60), 'silence_db': (-90, -5),
              'duration_tolerance': (0, 10), 'fps_tolerance': (0, 2),
              'max_peak_db': (-20, 3), 'loudness_target': (-50, 0),
              'loudness_tolerance': (0.1, 20)}
    for key, (lo, hi) in bounds.items():
        if key not in raw_settings:
            continue
        val = raw_settings[key]
        if key == 'loudness_target' and val in ('', None):
            settings[key] = None
            continue
        val = number(val, None)
        if val is None or not lo <= val <= hi:
            raise ValueError(f'Invalid check setting: {key}. Expected {lo} to {hi}.')
        settings[key] = val
    return {'schema': 'deliverycheck.project.v1', 'project': project,
            'manifest': rows, 'settings': settings}


def issue(code, severity, title, detail, start=None, end=None):
    return {'code': code, 'severity': severity, 'title': title, 'detail': detail,
            'start': round(start, 3) if start is not None else None,
            'end': round(end, 3) if end is not None else None,
            'review': 'open', 'note': ''}


def match_delivery(files, manifest):
    """Use exact case-insensitive basenames. Never infer spoken language from media."""
    byname = {}
    for f in files:
        byname.setdefault(f['name'].casefold(), []).append(f)
    matrix, issues, matches = [], [], {}
    expected = {r['filename'].casefold() for r in manifest}
    for r in manifest:
        found = byname.get(r['filename'].casefold(), [])
        state = 'missing' if not found else 'duplicate' if len(found) > 1 else 'matched'
        matrix.append({'filename': r['filename'], 'state': state,
                       'file_ids': [f['id'] for f in found], 'expected': r})
        if state == 'missing':
            issues.append(issue('missing_delivery', 'error', 'Missing deliverable', r['filename']))
        elif state == 'duplicate':
            issues.append(issue('duplicate_delivery', 'error', 'Ambiguous deliverable',
                                f"{r['filename']}: {len(found)} files share this name. Keep one version or rename them."))
        for f in found:
            matches[f['id']] = r
    if manifest:
        for f in files:
            if f['name'].casefold() not in expected:
                issues.append(issue('unexpected_file', 'review', 'Unlisted file', f['name']))
    # Duplicates also matter in quick scans, even without a delivery list.
    for name, found in byname.items():
        if len(found) > 1 and name not in expected:
            issues.append(issue('duplicate_name', 'review', 'Duplicate filename', found[0]['name']))
    return matrix, issues, matches


def probe(path):
    exe = binary('ffprobe')
    if not exe:
        raise RuntimeError('FFprobe is missing. Open the setup guide.')
    p = subprocess.run([exe, '-v', 'error', '-protocol_whitelist', 'file,pipe',
                        '-show_format', '-show_streams', '-of', 'json', str(path)],
                       capture_output=True, text=True, timeout=60, **process_options())
    if p.returncode:
        raise ValueError('This file could not be read as video. It may be incomplete, corrupt, or unsupported.')
    raw = json.loads(p.stdout)
    videos = [s for s in raw.get('streams', []) if s.get('codec_type') == 'video'
              and not s.get('disposition', {}).get('attached_pic')]
    audio = [s for s in raw.get('streams', []) if s.get('codec_type') == 'audio']
    if not videos:
        raise ValueError('No video track was found in this file.')
    v = videos[0]
    rotation = number(v.get('tags', {}).get('rotate'))
    for sd in v.get('side_data_list', []):
        if 'rotation' in sd:
            rotation = number(sd['rotation'])
    width, height = int(v.get('width', 0)), int(v.get('height', 0))
    sar = rate(v.get('sample_aspect_ratio', '1:1').replace(':', '/')) or 1
    display_w, display_h = (height, width) if abs(round(rotation)) % 180 == 90 else (width, height)
    dar = (height / (width * sar)) if display_w == height and abs(round(rotation)) % 180 == 90 else (width * sar / height if height else 0)
    a = audio[0] if audio else {}
    return {'width': display_w, 'height': display_h, 'coded_width': width, 'coded_height': height,
            'sample_aspect_ratio': sar, 'display_aspect_ratio': dar, 'rotation': rotation,
            'fps': round(rate(v.get('avg_frame_rate')) or rate(v.get('r_frame_rate')), 6),
            'duration': number(v.get('duration')) or number(raw.get('format', {}).get('duration')),
            'codec': v.get('codec_name', 'unknown'), 'pixel_format': v.get('pix_fmt', 'unknown'),
            'audio_tracks': len(audio), 'video_tracks': len(videos), 'audio_codec': a.get('codec_name'),
            'channels': a.get('channels', 0), 'sample_rate': int(number(a.get('sample_rate'))),
            'audio_duration': number(a.get('duration')) or None,
            'video_index': v['index'], 'audio_index': a.get('index'),
            'size_bytes': Path(path).stat().st_size,
            'container': raw.get('format', {}).get('format_name', 'unknown')}


def technical_checks(meta, expected, settings):
    out = []
    if not expected:
        return out
    for dim in ('width', 'height'):
        want = expected.get(dim)
        if want and meta[dim] != want:
            out.append(issue(dim, 'error', 'Wrong ' + dim,
                             f"Expected {int(want)} px. Found {meta[dim]} px after rotation."))
    if expected.get('width') and expected.get('height'):
        ratio = expected['width'] / expected['height']
        if abs(meta['display_aspect_ratio'] - ratio) > 0.01 and meta['sample_aspect_ratio'] != 1:
            out.append(issue('aspect', 'error', 'Wrong display aspect ratio',
                             'Non-square pixels change the displayed shape of this export.'))
    if expected.get('duration') and abs(meta['duration'] - expected['duration']) > settings['duration_tolerance'] + 1e-6:
        out.append(issue('duration', 'error', 'Wrong duration',
                         f"Expected {expected['duration']:g}s (+/-{settings['duration_tolerance']:g}s). Found {meta['duration']:.3f}s."))
    if expected.get('fps') and abs(meta['fps'] - expected['fps']) > settings['fps_tolerance'] + 1e-6:
        out.append(issue('fps', 'error', 'Wrong frame rate',
                         f"Expected {expected['fps']:g} fps. Found average {meta['fps']:.3f} fps."))
    if expected.get('codec') and expected['codec'] != meta['codec']:
        out.append(issue('codec', 'error', 'Wrong video codec',
                         f"Expected {expected['codec']}. Found {meta['codec']}."))
    if expected.get('audio_required') and not meta['audio_tracks']:
        out.append(issue('missing_audio', 'error', 'Required audio is missing', 'No audio track was found.'))
    return out


def parse_detection(log, duration, settings):
    out, measures = [], {'integrated_lufs': None, 'true_peak_db': None}
    for match in re.finditer(r'black_start:([\d.]+)\s+black_end:([\d.]+)\s+black_duration:([\d.]+)', log):
        start, end, length = map(float, match.groups())
        if length + 0.001 >= settings['black_seconds']:
            out.append(issue('black', 'review', 'Possible black gap',
                             f'{length:.2f}s near-black interval. Check whether this is an intended fade or cut.', start, end))
    for kind, start_pat, end_pat, minimum, title, detail in [
        ('freeze', r'freeze_start:\s*([\d.]+)', r'freeze_end:\s*([\d.]+)', settings['freeze_seconds'],
         'Possible frozen picture', 'Low-motion interval. A still, title card, or locked shot may be intentional.'),
        ('silence', r'silence_start:\s*([\d.]+)', r'silence_end:\s*([\d.]+)', settings['silence_seconds'],
         'Quiet audio interval', f"Audio below {settings['silence_db']:g} dB. Confirm whether the pause is intentional."),
    ]:
        token = re.compile(f'({start_pat})|({end_pat})')
        current = None
        for m in token.finditer(log):
            if m.group(2) is not None:
                current = float(m.group(2))
            elif current is not None:
                end = min(float(m.group(4)), duration)
                if end - current + 0.01 >= minimum:
                    out.append(issue(kind, 'review', title, detail, current, end))
                current = None
        if current is not None and duration - current + 0.01 >= minimum:
            out.append(issue(kind, 'review', title, detail, current, duration))
    summary = log.rsplit('Summary:', 1)[-1] if 'Summary:' in log else ''
    loud = re.search(r'Integrated loudness:\s*I:\s*([-\d.]+)\s*LUFS', summary)
    peak = re.search(r'True peak:\s*Peak:\s*([-\d.]+)\s*dBFS', summary)
    if loud:
        measures['integrated_lufs'] = number(loud.group(1), None)
    if peak:
        measures['true_peak_db'] = number(peak.group(1), None)
    if measures['true_peak_db'] is not None and measures['true_peak_db'] > settings['max_peak_db']:
        out.append(issue('peak', 'review', 'True peak above your limit',
                         f"Measured {measures['true_peak_db']:.1f} dBTP. Your limit is {settings['max_peak_db']:g} dBTP."))
    target = settings.get('loudness_target')
    if target is not None and measures['integrated_lufs'] is not None:
        if abs(measures['integrated_lufs'] - target) > settings['loudness_tolerance']:
            out.append(issue('loudness', 'review', 'Loudness outside your target',
                             f"Measured {measures['integrated_lufs']:.1f} LUFS. Target {target:g} +/-{settings['loudness_tolerance']:g} LUFS."))
    out.sort(key=lambda x: (x['start'] is None, x['start'] or 0, x['code']))
    return out, measures


def scan(path, meta, settings, cancel, progress):
    exe = binary('ffmpeg')
    if not exe:
        raise RuntimeError('FFmpeg is missing. Open the setup guide.')
    vf = (f"setpts=PTS-STARTPTS,blackdetect=d={settings['black_seconds']}:pix_th=0.10:pic_th=0.98,"
          f"freezedetect=n=-60dB:d={settings['freeze_seconds']}")
    cmd = [exe, '-hide_banner', '-nostdin', '-nostats', '-loglevel', 'info',
           '-threads', '2', '-protocol_whitelist', 'file,pipe', '-i', str(path),
           '-map', f"0:{meta['video_index']}", '-vf', vf]
    if meta['audio_tracks']:
        cmd += ['-map', f"0:{meta['audio_index']}", '-af',
                f"asetpts=PTS-STARTPTS,silencedetect=n={settings['silence_db']}dB:d={settings['silence_seconds']},ebur128=peak=true:framelog=verbose"]
    cmd += ['-progress', 'pipe:1', '-f', 'null', '-']
    started = time.monotonic()
    limit = max(180, min(meta['duration'] * 30 + 120, 7200))
    with tempfile.TemporaryFile(mode='w+b') as stderr:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=stderr, text=True, **process_options())
        def read_progress():
            for line in p.stdout:
                if line.startswith('out_time_us='):
                    seconds = number(line.strip().split('=', 1)[1]) / 1_000_000
                    progress(min(0.99, seconds / max(meta['duration'], 0.001)))
        reader = threading.Thread(target=read_progress, daemon=True)
        reader.start()
        try:
            while p.poll() is None:
                if cancel.is_set():
                    raise Cancelled()
                if time.monotonic() - started > limit:
                    raise TimeoutError('Analysis timed out. This file was not fully checked.')
                time.sleep(0.08)
        except BaseException:
            p.terminate()
            try:
                p.wait(timeout=3)
            except subprocess.TimeoutExpired:
                p.kill()
                p.wait()
            raise
        finally:
            reader.join(timeout=3)
            p.stdout.close()
        stderr.seek(0)
        log = stderr.read().decode('utf-8', errors='replace')
    if cancel.is_set():
        raise Cancelled()
    found, measures = parse_detection(log, meta['duration'], settings)
    bad_decode = re.search(r'Error (?:while|during)|Invalid data found|corrupt decoded frame|Packet corrupt|corrupt input packet', log, re.I)
    if p.returncode or bad_decode:
        found.append(issue('decode', 'error', 'Decode error or incomplete scan',
                           'The decoder reported a problem. Re-export or inspect the source before delivery.'))
    if meta['audio_tracks'] and measures['integrated_lufs'] is None:
        found.append(issue('audio_analysis', 'error', 'Audio measurement incomplete',
                           'No complete loudness summary was returned. This audio track has not passed analysis.'))
    progress(1)
    return found, measures


def analyze_file(file, expected, settings, cancel, progress):
    result = {k: file[k] for k in ('id', 'name', 'size')}
    result.update({'state': 'complete', 'metadata': None, 'issues': [], 'measurements': {},
                   'expected': expected, 'scan_scope': 'First video track and first audio track, full decoded duration.'})
    try:
        if cancel.is_set():
            raise Cancelled()
        meta = probe(file['path'])
        result['metadata'] = meta
        result['issues'] += technical_checks(meta, expected, settings)
        alerts, measures = scan(file['path'], meta, settings, cancel, progress)
        result['issues'] += alerts
        result['measurements'] = measures
        if any(i['code'] in ('decode', 'audio_analysis') for i in alerts):
            result['state'] = 'incomplete'
        if meta['video_tracks'] > 1 or meta['audio_tracks'] > 1:
            result['issues'].append(issue('additional_tracks', 'review', 'Additional tracks need review',
                                           'Only the first video and first audio tracks were decoded. Inspect other tracks separately.'))
    except Cancelled:
        result['state'] = 'cancelled'
        result['issues'].append(issue('cancelled', 'error', 'Scan cancelled', 'This video was not fully checked.'))
    except (OSError, ValueError, RuntimeError, TimeoutError, subprocess.SubprocessError) as e:
        result['state'] = 'incomplete'
        result['issues'].append(issue('unreadable', 'error', 'Could not complete this scan', str(e)[:400]))
    for n, item in enumerate(result['issues']):
        item['id'] = f"{file['id']}:{n}"
    return result


def summarize(report):
    issues = report.get('issues', []) + [i for f in report.get('files', []) for i in f.get('issues', [])]
    errors = sum(i['severity'] == 'error' for i in issues)
    open_reviews = sum(i['severity'] == 'review' and i.get('review') != 'accepted' for i in issues)
    accepted = sum(i.get('review') == 'accepted' for i in issues)
    complete = report.get('state') == 'complete' and all(f.get('state') == 'complete' for f in report.get('files', []))
    status = 'incomplete' if not complete else 'blocked' if errors else 'review' if open_reviews else 'checked'
    return {'status': status, 'errors': errors, 'open_reviews': open_reviews, 'accepted': accepted,
            'files': len(report.get('files', [])), 'expected': len(report.get('manifest', [])),
            'matched': sum(r['state'] == 'matched' for r in report.get('matrix', [])),
            'missing': sum(r['state'] == 'missing' for r in report.get('matrix', []))}
