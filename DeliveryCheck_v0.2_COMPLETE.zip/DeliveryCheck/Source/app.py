"""Run with python app.py. A private loopback app; no cloud or Python packages."""
from __future__ import annotations
import argparse
import copy
from datetime import datetime, timezone
import json
import mimetypes
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
import webbrowser

import engine

ROOT = Path(__file__).resolve().parent
TOKEN = secrets.token_urlsafe(32)
WORK = tempfile.TemporaryDirectory(prefix='deliverycheck_', ignore_cleanup_errors=True)
WORKDIR = Path(WORK.name)
FILES, JOBS = {}, {}
LOCK = threading.RLock()
ACTIVE = None
SERVER = None
SESSION_FILE = None
SESSION_CONFIG = None
LATEST = None
ENGINE_STATUS = None
WORKERS = []


def utc():
    return datetime.now(timezone.utc).isoformat()


def public_file(f):
    return {k: f[k] for k in ('id', 'name', 'size')}


def register(path, name=None):
    global LATEST
    f = {'id': secrets.token_hex(8), 'name': name or path.name,
         'path': str(path), 'size': path.stat().st_size}
    with LOCK:
        FILES[f['id']] = f
        LATEST = None
    return public_file(f)


def run_job(job_id, files, config):
    global ACTIVE
    job = JOBS[job_id]
    matrix, findings, matched = engine.match_delivery(files, config['manifest'])
    for n, item in enumerate(findings):
        item['id'] = 'batch:' + str(n)
    with LOCK:
        job.update({'matrix': matrix, 'issues': findings})
    for index, file in enumerate(files):
        if job['cancel'].is_set():
            break
        with LOCK:
            job['current'] = file['name']
        def progress(fraction):
            with LOCK:
                job['progress'] = (index + fraction) / len(files)
        result = engine.analyze_file(file, matched.get(file['id']), config['settings'], job['cancel'], progress)
        with LOCK:
            job['files'].append(result)
    with LOCK:
        job['state'] = 'cancelled' if job['cancel'].is_set() else 'complete'
        job['finished_at'] = utc()
        job['current'] = ''
        if job['state'] == 'complete':
            job['progress'] = 1
        if ACTIVE == job_id:
            ACTIVE = None


def guarded_job(job_id, files, config):
    global ACTIVE
    try:
        run_job(job_id, files, config)
    except Exception as exc:
        with LOCK:
            job = JOBS[job_id]
            problem = engine.issue('analysis_failed', 'error', 'Analysis did not finish',
                                   str(exc)[:250] or 'Run the check again.')
            problem['id'] = 'batch:failed'
            job['issues'].append(problem)
            job.update(state='failed', finished_at=utc(), current='')
            ACTIVE = None


def report(job):
    with LOCK:
        r = copy.deepcopy({k: v for k, v in job.items() if k != 'cancel'})
    r['summary'] = engine.summarize(r)
    return r


class Handler(BaseHTTPRequestHandler):
    server_version = 'DeliveryCheck/0.2'

    def log_message(self, *args):
        pass

    def json(self, data, status=200):
        payload = json.dumps(data, ensure_ascii=False, allow_nan=False).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(payload)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(payload)

    def body(self):
        size = int(self.headers.get('Content-Length', '0'))
        if not 0 <= size <= 2_000_000:
            raise ValueError('This request is too large.')
        return json.loads(self.rfile.read(size) or b'{}')

    def authorized(self, media=False):
        host = self.headers.get('Host', '')
        if host not in (f'127.0.0.1:{self.server.server_port}', f'localhost:{self.server.server_port}'):
            self.json({'error': 'Use the local app address printed by the launcher.'}, 403)
            return False
        origin = self.headers.get('Origin')
        if origin and origin not in (f'http://127.0.0.1:{self.server.server_port}', f'http://localhost:{self.server.server_port}'):
            self.json({'error': 'This request must come from the local app.'}, 403)
            return False
        supplied = self.headers.get('X-DeliveryCheck-Token', '')
        if media:
            supplied = parse_qs(urlparse(self.path).query).get('token', [supplied])[0]
        if not secrets.compare_digest(supplied, TOKEN):
            self.json({'error': 'Reload the app to reconnect to this session.'}, 403)
            return False
        return True

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        parts = urlparse(self.path)
        route = parts.path
        args = parse_qs(parts.query)
        if route.startswith('/api/') and not self.authorized(media=route in ('/api/media', '/api/frame')):
            return
        try:
            if route == '/api/health':
                self.json({'application': 'DeliveryCheck', 'pid': os.getpid(),
                           'version': engine.VERSION, 'engine': ENGINE_STATUS or engine.tool_status(),
                           'demo_available': (ROOT / 'demo' / 'project.json').exists()})
            elif route == '/api/workspace':
                with LOCK:
                    job = JOBS.get(LATEST)
                    self.json({'files': [public_file(f) for f in FILES.values()],
                               'config': SESSION_CONFIG,
                               'report': report(job) if job else None})
            elif route == '/api/job':
                job = JOBS.get(args.get('id', [''])[0])
                self.json(report(job) if job else {'error': 'Scan not found.'}, 200 if job else 404)
            elif route == '/api/media':
                f = FILES.get(args.get('id', [''])[0])
                if not f:
                    self.json({'error': 'Media is no longer attached.'}, 404)
                    return
                self.send_file(Path(f['path']))
            elif route == '/api/frame':
                f = FILES.get(args.get('id', [''])[0])
                second = engine.number(args.get('t', [0])[0], 0)
                if not f or not 0 <= second <= 86400:
                    raise ValueError('Select a valid video and timestamp.')
                dest = WORKDIR / f"{f['id']}_frame_{second:.3f}.jpg"
                if not dest.exists():
                    p = subprocess.run([engine.binary('ffmpeg'), '-hide_banner', '-loglevel', 'error',
                                        '-nostdin', '-protocol_whitelist', 'file,pipe', '-ss', str(second),
                                        '-i', f['path'], '-frames:v', '1', '-vf', 'scale=960:540:force_original_aspect_ratio=decrease',
                                        '-q:v', '3', '-y', str(dest)], capture_output=True, timeout=40,
                                       **engine.process_options())
                    if p.returncode or not dest.exists():
                        self.json({'error': 'Could not capture this frame.'}, 422)
                        return
                self.send_file(dest)
            elif route == '/':
                content = (ROOT / 'web' / 'index.html').read_text(encoding='utf-8').replace('"__SESSION_TOKEN__"', json.dumps(TOKEN))
                self.send_bytes(content.encode(), 'text/html; charset=utf-8')
            elif route in ('/app.js', '/style.css'):
                self.send_file(ROOT / 'web' / route[1:])
            elif route == '/guide':
                self.send_file(ROOT / 'START_HERE.html')
            elif route.startswith(('/docs/', '/demo/')):
                target = (ROOT / route.lstrip('/')).resolve()
                allowed = any(target.is_relative_to(ROOT / folder) for folder in ('docs', 'demo'))
                if allowed and target.is_file() and target.suffix in ('.png', '.html', '.json', '.csv', '.md'):
                    self.send_file(target)
                else:
                    self.json({'error': 'Not found.'}, 404)
            else:
                self.json({'error': 'Not found.'}, 404)
        except (OSError, ValueError, subprocess.SubprocessError) as e:
            self.json({'error': str(e)[:300]}, 400)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def send_bytes(self, data, mime):
        self.send_response(200)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' blob: data:; media-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'; object-src 'none'")
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(data)

    def send_file(self, path):
        size = path.stat().st_size
        start, end = 0, size - 1
        partial = False
        request_range = self.headers.get('Range', '')
        if request_range:
            import re
            m = re.fullmatch(r'bytes=(\d*)-(\d*)', request_range)
            if not m or not (m[1] or m[2]):
                self.json({'error': 'Invalid range.'}, 416)
                return
            if m[1]:
                start = int(m[1]); end = min(int(m[2]), size - 1) if m[2] else size - 1
            else:
                start = max(0, size - int(m[2]))
            if start > end or start >= size:
                self.send_response(416)
                self.send_header('Content-Range', f'bytes */{size}')
                self.end_headers()
                return
            partial = True
        self.send_response(206 if partial else 200)
        self.send_header('Content-Type', mimetypes.guess_type(path.name)[0] or 'application/octet-stream')
        self.send_header('Accept-Ranges', 'bytes')
        self.send_header('Content-Length', str(end - start + 1))
        self.send_header('Cache-Control', 'no-store')
        if partial:
            self.send_header('Content-Range', f'bytes {start}-{end}/{size}')
        self.end_headers()
        if self.command == 'HEAD':
            return
        try:
            with path.open('rb') as stream:
                stream.seek(start)
                remaining = end - start + 1
                while remaining:
                    chunk = stream.read(min(256 * 1024, remaining))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    remaining -= len(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_POST(self):
        global ACTIVE, LATEST, SESSION_CONFIG
        if not self.authorized():
            return
        route = urlparse(self.path).path
        try:
            data = self.body()
            if route == '/api/workspace':
                with LOCK:
                    if ACTIVE:
                        raise ValueError('Wait for the scan to finish before changing this project.')
                    SESSION_CONFIG = engine.validate_config(data.get('config', {}))
                    LATEST = None
                self.json({'ok': True})
            elif route == '/api/start':
                config = engine.validate_config(data.get('config', {}))
                ids = data.get('file_ids', [])
                if not isinstance(ids, list) or not 1 <= len(ids) <= 500 or len(set(ids)) != len(ids):
                    raise ValueError('Add between 1 and 500 unique video files.')
                if not engine.tool_status()['ready']:
                    self.json({'error': 'FFmpeg and FFprobe are required. Open the setup guide.'}, 409)
                    return
                with LOCK:
                    if ACTIVE and JOBS[ACTIVE]['state'] == 'running':
                        self.json({'error': 'A scan is already running. Wait or cancel it.'}, 409)
                        return
                    if any(i not in FILES for i in ids):
                        raise ValueError('Some files are no longer attached. Add them again.')
                    files = [FILES[i].copy() for i in ids]
                    jid = secrets.token_hex(8)
                    JOBS[jid] = {**config, 'schema': 'deliverycheck.report.v1', 'id': jid,
                                 'app_version': engine.VERSION, 'engine': engine.tool_status(),
                                 'state': 'running', 'created_at': utc(), 'finished_at': None,
                                 'input_count': len(files), 'files': [], 'issues': [], 'matrix': [],
                                 'progress': 0, 'current': '', 'cancel': threading.Event()}
                    ACTIVE = jid
                    LATEST = jid
                    SESSION_CONFIG = config
                worker = threading.Thread(target=guarded_job, args=(jid, files, config), daemon=True)
                WORKERS.append(worker)
                worker.start()
                self.json({'id': jid})
            elif route == '/api/cancel':
                with LOCK:
                    job = JOBS.get(data.get('id'))
                    if job:
                        job['cancel'].set()
                self.json({'ok': True})
            elif route == '/api/review':
                with LOCK:
                    job = JOBS.get(data.get('job_id'))
                    if not job or job['state'] != 'complete':
                        raise ValueError('Wait for a complete scan before reviewing findings.')
                    candidates = job['issues'] + [i for f in job['files'] for i in f['issues']]
                    finding = next((i for i in candidates if i['id'] == data.get('issue_id')), None)
                    if not finding or finding['severity'] != 'review':
                        raise ValueError('Technical errors must be fixed and scanned again.')
                    state = data.get('review')
                    if state not in ('open', 'accepted', 'fix'):
                        raise ValueError('Invalid review state.')
                    note = str(data.get('note', '')).strip()[:1000]
                    if state == 'accepted' and not note:
                        raise ValueError('Add a short reason for accepting this alert.')
                    finding.update({'review': state, 'note': note, 'reviewed_at': utc()})
                self.json(report(job))
            elif route == '/api/demo':
                with LOCK:
                    if ACTIVE:
                        raise ValueError('Wait for the scan to finish before loading the sample.')
                config = json.loads((ROOT / 'demo' / 'project.json').read_text(encoding='utf-8'))
                SESSION_CONFIG = engine.validate_config(config)
                files = [register(p) for p in sorted((ROOT / 'demo' / 'videos').glob('*')) if p.suffix.lower() in engine.EXTENSIONS]
                self.json({'config': config, 'files': files})
            elif route == '/api/reset':
                with LOCK:
                    if ACTIVE and JOBS.get(ACTIVE, {}).get('state') == 'running':
                        raise ValueError('Wait for the scan to finish before starting a new project.')
                    for target in WORKDIR.iterdir():
                        if target.is_file() and target.parent == WORKDIR:
                            try:
                                target.unlink(missing_ok=True)
                            except PermissionError:
                                pass  # An active Windows preview may release it shortly.
                    FILES.clear()
                    JOBS.clear()
                    ACTIVE = None
                    LATEST = None
                    SESSION_CONFIG = None
                self.json({'ok': True})
            elif route == '/api/shutdown':
                with LOCK:
                    for job in JOBS.values():
                        job['cancel'].set()
                self.json({'ok': True})
                if SERVER is not None:
                    threading.Thread(target=SERVER.shutdown, daemon=True).start()
            elif route == '/api/remove':
                with LOCK:
                    if ACTIVE and JOBS[ACTIVE]['state'] == 'running':
                        raise ValueError('Wait for the scan to finish before removing files.')
                    f = FILES.pop(data.get('id'), None)
                    if f and Path(f['path']).parent == WORKDIR:
                        try:
                            Path(f['path']).unlink(missing_ok=True)
                        except PermissionError:
                            pass
                    LATEST = None
                self.json({'ok': True})
            else:
                self.json({'error': 'Not found.'}, 404)
        except (OSError, ValueError, TypeError, KeyError) as e:
            self.json({'error': str(e)[:400]}, 400)

    def do_PUT(self):
        if not self.authorized():
            return
        if urlparse(self.path).path != '/api/file':
            self.json({'error': 'Not found.'}, 404)
            return
        dest = None
        try:
            name = parse_qs(urlparse(self.path).query).get('name', [''])[0]
            name = name.replace('\\', '/').rsplit('/', 1)[-1]
            if Path(name).suffix.lower() not in engine.EXTENSIONS or len(name) > 240:
                raise ValueError('Choose an MP4, MOV, MKV, WEBM, M4V, AVI, MXF, MPG, or MPEG video.')
            size = int(self.headers.get('Content-Length', '0'))
            if not 0 < size <= 8 * 1024 ** 3:
                raise ValueError('Choose a non-empty video up to 8 GB per file.')
            if size + 250 * 1024 ** 2 > shutil.disk_usage(WORKDIR).free:
                raise ValueError('Not enough temporary disk space to stage this video.')
            dest = WORKDIR / (secrets.token_hex(16) + Path(name).suffix.lower())
            self.connection.settimeout(180)
            with dest.open('wb') as stream:
                remaining = size
                while remaining:
                    chunk = self.rfile.read(min(1024 * 1024, remaining))
                    if not chunk:
                        raise ValueError('The file transfer was interrupted.')
                    stream.write(chunk)
                    remaining -= len(chunk)
            self.json(register(dest, name))
        except (OSError, ValueError) as e:
            if dest:
                dest.unlink(missing_ok=True)
            self.json({'error': str(e)[:300]}, 400)


def main():
    global SERVER, SESSION_FILE, ENGINE_STATUS
    parser = argparse.ArgumentParser(description='DeliveryCheck local video delivery checker')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--no-browser', action='store_true')
    parser.add_argument('--session-file', type=Path, default=None)
    args = parser.parse_args()
    ENGINE_STATUS = engine.tool_status()
    try:
        server = ThreadingHTTPServer(('127.0.0.1', args.port), Handler)
    except OSError:
        if args.port != 8765:
            raise
        server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    SERVER = server
    SESSION_FILE = args.session_file
    url = f'http://127.0.0.1:{server.server_port}'
    if SESSION_FILE:
        SESSION_FILE.parent.mkdir(parents=True, exist_ok=True)
        temporary = SESSION_FILE.with_suffix('.tmp')
        temporary.write_text(json.dumps({'url': url, 'token': TOKEN, 'pid': os.getpid(),
                                         'version': engine.VERSION, 'started_at': utc()}), encoding='utf-8')
        os.replace(temporary, SESSION_FILE)
    print(f'\nDeliveryCheck {engine.VERSION}\nOpen {url}\nKeep this window open. Press Ctrl+C to quit.\n', flush=True)
    if not args.no_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever(poll_interval=0.3)
    except KeyboardInterrupt:
        pass
    finally:
        for j in JOBS.values():
            j['cancel'].set()
        for worker in WORKERS:
            worker.join(timeout=10)
        server.server_close()
        WORK.cleanup()
        if SESSION_FILE:
            try:
                SESSION_FILE.unlink(missing_ok=True)
            except OSError:
                pass


if __name__ == '__main__':
    main()
