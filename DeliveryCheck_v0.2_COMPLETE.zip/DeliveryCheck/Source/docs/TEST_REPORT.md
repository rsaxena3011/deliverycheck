# DeliveryCheck 0.2.0 verification

Date: 6 October 2026

## Release status

Working local app with an automatic Windows x64 launcher. The launcher is a native PE GUI that embeds the app source, downloads pinned Python and FFmpeg archives, verifies their SHA256 values, extracts them per user and starts the local app. Its setup runs on a worker thread with progress, cancel, retry and log controls. The executable was compiled with warnings treated as errors and structurally inspected in Linux. Native Windows execution was not available here. Windows 10/11 setup and repair tests remain required before calling this a validated commercial Windows release.

## Environment used for functional checks

- Linux x86_64.
- Python 3.12.14.
- FFmpeg and FFprobe 6.1.1.
- Chromium 153, controlled with Playwright for browser verification.
- Desktop viewport: 1440 x 1100 and 1366 x 768.
- Responsive viewport: 390 x 844.
- Zig 0.16.0 cross-compiler for the Windows x64 launcher PE.

## Automated engine tests

All 16 tests passed. The full log is in ENGINE_TEST_LOG.txt and the runnable tests are in ../tests/test_engine.py.

The tests cover missing and duplicate deliverables, seeded picture and audio faults, timestamp accuracy, freeze endings, loudness and true peak measurements, unchanged originals, corrupt media, cancellation, invalid settings and paths, optional audio, wrong codec and duration, review decisions and rotation-aware dimensions.

## Browser workflow verification

All checks below passed. The execution log is in BROWSER_TEST_LOG.txt.

- Load the sample videos and run the FFmpeg-backed scan from the interface.
- Show six technical errors, three timestamped review alerts and four of five filename matches.
- Click a timestamp and inspect a captured frame.
- Accept an intentional alert with a note, then reopen it.
- Download and inspect HTML, CSV and JSON reports.
- Generate a twelve-file campaign list, export it as a preset and import another preset.
- Clear stale scan results after requirements change.
- Display the interface at 390 pixels wide without page-level horizontal overflow.
- Import a real video through the browser file input and complete a clean quick scan.
- Reject requests without the local session token and reject requests from another origin.
- Support HTTP byte ranges for seeking media.
- Reject an invalid delivery preset and prevent technical errors from being manually waived.
- Cancel an active batch and keep its result marked incomplete.
- Open the guide and embedded screenshots through the local app.
- Open the exported HTML report without a running app.
- Verify New project, Upload videos, Add a folder and Run check are within the 1366 x 768 viewport without scrolling.
- Restore files, settings and scan results after a browser reload.
- Keep old results invalid after requirements change and the browser reloads.
- Clear staged files, results and stale scan status through New project, with optional requirement retention.
- Import a folder, ignore non-video files and reset the folder input for reuse.
- Recover an active scan when the browser reloads after scan acceptance.
- Confirm that Quit stops the server process and removes its session file.
- No uncaught JavaScript errors and no external app requests during tested flows.

## Launcher structural verification

- Output is a PE32+ Windows x64 GUI executable.
- The embedded app payload extracts to a valid source tree and passes Python and JavaScript syntax checks.
- The executable contains the official Python and FFmpeg URLs, SHA256 values and extraction code.
- The launcher writes a private per-user install, keeps FFmpeg private to the child process and records a local session file.
- Both complete publisher archives were downloaded in the QA environment. Their hashes match the pinned values below, and their internal executable paths match the launcher's extraction paths.
- The source repairs Python's embedded import path on every launch and verifies Python, FFmpeg and FFprobe before starting the app.
- Existing sessions are validated by their authenticated local health endpoint. The launcher uses --no-browser on the Python process, then opens a single browser tab itself.

| Runtime | Verified SHA256 |
| --- | --- |
| Python 3.13.16 Windows x64 embeddable | 97dae5274cc54867065e8d5a3226e48c35017ed332a0fdb0e27d5b5821961297 |
| FFmpeg 8.1.2 essentials ZIP | db580001caa24ac104c8cb856cd113a87b0a443f7bdf47d8c12b1d740584a2ec |

## Seeded sample results

| File | Expected finding | Observed |
| --- | --- | --- |
| launch_en_6s_vertical.mp4 | Black gap near 2.00 to 2.53 seconds | 2.000 to 2.533 seconds |
| launch_en_6s_vertical.mp4 | Silence near 3.00 to 4.00 seconds | 3.008 to 4.011 seconds |
| launch_hi_6s_vertical.mp4 | Frozen ending near 4.00 to 6.00 seconds | 3.967 to 6.000 seconds |
| launch_hi_6s_vertical.mp4 | Required audio missing | Found |
| launch_en_6s_square.mp4 | Wrong width, height, duration and FPS | All four found |
| launch_en_6s_landscape.mp4 | Clean control | No issues found |
| launch_hi_6s_square.mp4 | Missing file | Found |

The sample timestamps include codec-frame and AAC-buffer rounding. The assertions allow small encoded-media tolerances.

## Coverage limits

- Native Windows execution, macOS, Safari and Firefox were not available in this environment.
- Large 4K and 8K footage, HDR content, long-form media and the 8 GB per-file limit were not load-tested.
- Analysis covers the first video and first audio tracks only.
- Average frame rate is checked. Variable-frame-rate cadence is not certified.
- Language, spelling, safe areas, subtitles, creative quality and synchronization remain outside this build's scope.
- Intentional dark scenes, title-card holds and pauses may trigger review alerts. Thresholds and acceptance notes are provided for that reason.
