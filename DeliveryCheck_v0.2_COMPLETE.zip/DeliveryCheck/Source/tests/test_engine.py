import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import engine


class EngineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.config = engine.validate_config(json.loads((ROOT / 'demo' / 'project.json').read_text()))
        cls.files = [{'id':str(n),'name':p.name,'path':str(p),'size':p.stat().st_size}
                     for n,p in enumerate(sorted((ROOT / 'demo' / 'videos').glob('*.mp4')))]
        cls.matrix, cls.findings, cls.matches = engine.match_delivery(cls.files, cls.config['manifest'])
        cls.before = [hashlib.sha256(Path(f['path']).read_bytes()).hexdigest() for f in cls.files]
        cls.results = {f['name']: engine.analyze_file(f,cls.matches[f['id']],cls.config['settings'],
                       threading.Event(),lambda _:None) for f in cls.files}

    def test_manifest_finds_missing_delivery(self):
        missing = [r['filename'] for r in self.matrix if r['state']=='missing']
        self.assertEqual(missing,['launch_hi_6s_square.mp4'])

    def test_known_faults_are_detected_without_extra_faults(self):
        expected=json.loads((ROOT/'demo'/'expected_findings.json').read_text())
        for name,r in self.results.items():
            self.assertEqual({i['code'] for i in r['issues']},set(expected[name]['codes']),name)
            self.assertEqual(r['state'],'complete')

    def test_timestamp_accuracy_with_encoded_audio_tolerance(self):
        r=self.results['launch_en_6s_vertical.mp4']
        black=next(i for i in r['issues'] if i['code']=='black')
        silence=next(i for i in r['issues'] if i['code']=='silence')
        self.assertAlmostEqual(black['start'],2,delta=.04)
        self.assertAlmostEqual(black['end'],2.533,delta=.04)
        self.assertAlmostEqual(silence['start'],3,delta=.05)
        self.assertAlmostEqual(silence['end'],4,delta=.05)

    def test_trailing_freeze_reaches_last_frame(self):
        r=self.results['launch_hi_6s_vertical.mp4']
        freeze=next(i for i in r['issues'] if i['code']=='freeze')
        self.assertAlmostEqual(freeze['start'],3.967,delta=.04)
        self.assertAlmostEqual(freeze['end'],6,delta=.04)

    def test_measurements_are_real(self):
        m=self.results['launch_en_6s_landscape.mp4']['measurements']
        self.assertTrue(-23<m['integrated_lufs']<-20)
        self.assertTrue(-19<m['true_peak_db']<-14)

    def test_originals_unchanged(self):
        after=[hashlib.sha256(Path(f['path']).read_bytes()).hexdigest() for f in self.files]
        self.assertEqual(self.before,after)

    def test_corrupt_media_never_passes(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'bad.mp4';p.write_bytes(b'not a video')
            r=engine.analyze_file({'id':'bad','name':p.name,'path':str(p),'size':p.stat().st_size},None,
                                  self.config['settings'],threading.Event(),lambda _:None)
            self.assertEqual(r['state'],'incomplete')
            self.assertEqual(r['issues'][0]['severity'],'error')

    def test_cancellation_never_passes(self):
        event=threading.Event();event.set()
        r=engine.analyze_file(self.files[0],None,self.config['settings'],event,lambda _:None)
        self.assertEqual(r['state'],'cancelled')

    def test_duplicate_names_are_ambiguous(self):
        copies=self.files+[dict(self.files[0],id='duplicate',name=self.files[0]['name'].upper())]
        m,findings,_=engine.match_delivery(copies,self.config['manifest'])
        self.assertEqual(sum(r['state']=='duplicate' for r in m),1)
        self.assertTrue(any(i['code']=='duplicate_delivery' for i in findings))

    def test_invalid_config_is_rejected(self):
        for mutate in [lambda c:c['settings'].update(black_seconds=float('nan')),
                       lambda c:c['settings'].update(silence_seconds=-1),
                       lambda c:c['manifest'].append(c['manifest'][0]),
                       lambda c:c['manifest'][0].update(filename='../escape.mp4')]:
            c=copy.deepcopy(self.config);mutate(c)
            with self.assertRaises(ValueError):engine.validate_config(c)

    def test_optional_audio_does_not_fail(self):
        m=self.results['launch_hi_6s_vertical.mp4']['metadata']
        r=dict(self.config['manifest'][1],audio_required=False)
        self.assertNotIn('missing_audio',[i['code'] for i in engine.technical_checks(m,r,self.config['settings'])])

    def test_wrong_codec_and_duration_are_checked(self):
        m=self.results['launch_en_6s_landscape.mp4']['metadata']
        expected={'width':640,'height':360,'fps':30,'duration':15,'codec':'hevc','audio_required':True}
        self.assertEqual({i['code'] for i in engine.technical_checks(m,expected,self.config['settings'])},{'duration','codec'})

    def test_accepted_alerts_do_not_hide_technical_errors(self):
        r={'state':'complete','files':list(copy.deepcopy(self.results).values()),'issues':copy.deepcopy(self.findings),
           'manifest':self.config['manifest'],'matrix':self.matrix}
        for f in r['files']:
            for i in f['issues']:
                if i['severity']=='review':i['review']='accepted'
        self.assertEqual(engine.summarize(r)['status'],'blocked')
        self.assertEqual(engine.summarize(r)['errors'],6)

    def test_trailing_silence_and_freeze_log(self):
        log='lavfi.freezedetect.freeze_start: 4\n silence_start: 5\n'
        alerts,_=engine.parse_detection(log,8,self.config['settings'])
        self.assertEqual([(a['code'],a['start'],a['end']) for a in alerts],[('freeze',4,8),('silence',5,8)])

    def test_all_silent_track_is_reviewable(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'silent.mp4'
            subprocess.run([engine.binary('ffmpeg'),'-v','error','-y','-i',self.files[0]['path'],
                            '-af','volume=0','-c:v','copy','-t','2',str(p)],check=True)
            f={'id':'silent','name':p.name,'path':str(p),'size':p.stat().st_size}
            r=engine.analyze_file(f,None,self.config['settings'],threading.Event(),lambda _:None)
            self.assertEqual(r['state'],'complete')
            self.assertTrue(any(i['code']=='silence' for i in r['issues']))

    def test_rotation_swaps_display_dimensions(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'rotated.mp4'
            subprocess.run([engine.binary('ffmpeg'),'-v','error','-y','-display_rotation','90','-i',self.files[0]['path'],
                            '-c','copy',str(p)],check=True)
            m=engine.probe(p)
            self.assertEqual((m['width'],m['height']),(360,640))
            self.assertAlmostEqual(m['display_aspect_ratio'],360/640)


if __name__=='__main__':unittest.main(verbosity=2)
