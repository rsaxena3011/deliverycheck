"""Create original synthetic QA clips. No third-party media assets."""
import json
from pathlib import Path
import subprocess
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import engine

ROOT = Path(__file__).resolve().parents[1]
DEMO = ROOT / 'demo'
OUT = DEMO / 'videos'
OUT.mkdir(parents=True, exist_ok=True)


def make(name, size='360x640', duration=6, fps=30, audio=True, video_filter=None, audio_filter=None):
    cmd = [engine.binary('ffmpeg'), '-hide_banner', '-loglevel', 'error', '-y',
           '-f', 'lavfi', '-i', f'testsrc2=s={size}:r={fps}:d={duration}']
    if audio:
        cmd += ['-f', 'lavfi', '-i', f'sine=frequency=440:sample_rate=48000:duration={duration}']
    cmd += ['-map', '0:v:0']
    if audio:
        cmd += ['-map', '1:a:0', '-c:a', 'aac', '-b:a', '128k']
        if audio_filter:
            cmd += ['-af', audio_filter]
    if video_filter:
        cmd += ['-vf', video_filter]
    cmd += ['-c:v', 'libx264', '-preset', 'fast', '-crf', '25', '-pix_fmt', 'yuv420p', '-t', str(duration),
            '-movflags', '+faststart', str(OUT / name)]
    subprocess.run(cmd, check=True)


make('launch_en_6s_vertical.mp4', video_filter="drawbox=x=0:y=0:w=iw:h=ih:color=black:t=fill:enable='between(t,2,2.5)'",
     audio_filter="volume=enable='between(t,3,4)':volume=0")
make('launch_hi_6s_vertical.mp4', audio=False,
     video_filter='trim=duration=4,tpad=stop_mode=clone:stop_duration=2')
make('launch_en_6s_square.mp4', size='480x270', duration=5, fps=24)
make('launch_en_6s_landscape.mp4', size='640x360')

rows = []
for lang, form, width, height in [('en','vertical',360,640),('hi','vertical',360,640),
                                 ('en','square',360,360),('en','landscape',640,360),('hi','square',360,360)]:
    rows.append({'filename':f'launch_{lang}_6s_{form}.mp4','width':width,'height':height,
                 'duration':6,'fps':30,'codec':'h264','audio_required':True,'language':lang})
config = {'schema':'deliverycheck.project.v1','project':'Launch campaign / sample delivery',
          'manifest':rows,'settings':engine.DEFAULTS}
(DEMO/'project.json').write_text(json.dumps(config, indent=2))
expected = {
    'launch_en_6s_vertical.mp4': {'codes':['black','silence'], 'black_start':2.0, 'black_end':2.533, 'silence_start':3.0, 'silence_end':4.0},
    'launch_hi_6s_vertical.mp4': {'codes':['freeze','missing_audio'], 'freeze_start':3.967, 'freeze_end':6.0},
    'launch_en_6s_square.mp4': {'codes':['width','height','fps','duration']},
    'launch_en_6s_landscape.mp4': {'codes':[]},
    'delivery_list': {'codes':['missing_delivery'], 'missing':'launch_hi_6s_square.mp4'},
}
(DEMO/'expected_findings.json').write_text(json.dumps(expected,indent=2))
print('Created 4 synthetic videos and a 5-file expected delivery list.')
