/* DeliveryCheck Windows x64 bootstrap. No global installs or elevated rights. */
#ifndef UNICODE
#define UNICODE
#endif
#define _UNICODE
#include <windows.h>
#include <commctrl.h>
#include <shellapi.h>
#include <shlobj.h>
#include <winhttp.h>
#include <bcrypt.h>
#include <stdio.h>
#include <wchar.h>
#include <stdint.h>
#include "app_bundle.h"

#define CAP 2048
#define WM_STATUS (WM_APP+1)
#define WM_DONE (WM_APP+2)
#define ID_RETRY 101
#define ID_FOLDER 102
#define ID_CLOSE 103

static HWND window, label, progress, retry_button, folder_button, close_button;
static HFONT font;
static volatile LONG cancelled;
static int working = 1;
static wchar_t root[CAP], session_path[CAP], log_path[CAP], current_stage[256];
static HANDLE setup_lock;

static int exists(const wchar_t *path) {
    DWORD a = GetFileAttributesW(path);
    return a != INVALID_FILE_ATTRIBUTES && !(a & FILE_ATTRIBUTE_DIRECTORY);
}
static int directory(const wchar_t *path) {
    int result = SHCreateDirectoryExW(NULL, path, NULL);
    return result == ERROR_SUCCESS || result == ERROR_ALREADY_EXISTS || result == ERROR_FILE_EXISTS;
}
static void path_join(wchar_t *out, const wchar_t *base, const wchar_t *leaf) {
    swprintf(out, CAP, L"%ls\\%ls", base, leaf);
}
static void log_line(const wchar_t *message) {
    FILE *fp = _wfopen(log_path, L"a, ccs=UTF-8");
    if (fp) { fwprintf(fp, L"%ls\n", message); fclose(fp); }
}
static void status(const wchar_t *message, int value) {
    wchar_t *copy = _wcsdup(message);
    if (copy && !PostMessageW(window, WM_STATUS, (WPARAM)value, (LPARAM)copy)) free(copy);
}
static void stage(const wchar_t *message, int value) {
    wcsncpy(current_stage, message, 255); current_stage[255] = 0;
    log_line(message); status(message, value);
}
static int write_bytes(const wchar_t *path, const void *data, DWORD size) {
    HANDLE h = CreateFileW(path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) return 0;
    DWORD wrote = 0; int ok = WriteFile(h, data, size, &wrote, NULL) && wrote == size;
    CloseHandle(h); return ok;
}
static int write_utf8(const wchar_t *path, const wchar_t *text) {
    int n = WideCharToMultiByte(CP_UTF8, 0, text, -1, NULL, 0, NULL, NULL);
    char *bytes = malloc((size_t)n); if (!bytes) return 0;
    WideCharToMultiByte(CP_UTF8, 0, text, -1, bytes, n, NULL, NULL);
    int ok = write_bytes(path, bytes, (DWORD)(n - 1)); free(bytes); return ok;
}
static int hash_matches(const wchar_t *path, const char *expected) {
    BCRYPT_ALG_HANDLE alg = NULL; BCRYPT_HASH_HANDLE hash = NULL;
    HANDLE file = INVALID_HANDLE_VALUE; PUCHAR object = NULL;
    DWORD size = 0, got = 0, ignored = 0; BYTE digest[32], buffer[65536]; int ok = 0;
    if (BCryptOpenAlgorithmProvider(&alg, BCRYPT_SHA256_ALGORITHM, NULL, 0)) goto done;
    if (BCryptGetProperty(alg, BCRYPT_OBJECT_LENGTH, (PUCHAR)&size, sizeof(size), &ignored, 0)) goto done;
    object = malloc(size); if (!object) goto done;
    if (BCryptCreateHash(alg, &hash, object, size, NULL, 0, 0)) goto done;
    file = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
    if (file == INVALID_HANDLE_VALUE) goto done;
    for (;;) {
        if (!ReadFile(file, buffer, sizeof(buffer), &got, NULL) || cancelled) goto done;
        if (!got) break;
        if (BCryptHashData(hash, buffer, got, 0)) goto done;
    }
    if (BCryptFinishHash(hash, digest, sizeof(digest), 0)) goto done;
    char actual[65]; for (int i=0; i<32; ++i) sprintf(actual+i*2, "%02x", digest[i]); actual[64]=0;
    ok = strcmp(actual, expected) == 0;
done:
    if (file != INVALID_HANDLE_VALUE) CloseHandle(file);
    if (hash) BCryptDestroyHash(hash);
    free(object);
    if (alg) BCryptCloseAlgorithmProvider(alg, 0);
    return ok;
}

static int download(const wchar_t *host, const wchar_t *resource, const wchar_t *dest,
                    const char *checksum, const wchar_t *name, int base, int span) {
    if (exists(dest) && hash_matches(dest, checksum)) return 1;
    wchar_t partial[CAP]; swprintf(partial, CAP, L"%ls.part", dest);
    HINTERNET http = NULL, conn = NULL, request = NULL;
    HANDLE file = INVALID_HANDLE_VALUE; DWORD code = 0, length = sizeof(code), total = 0, got = 0, wrote = 0;
    uint64_t received = 0; int ok = 0, last = -1; BYTE buffer[65536];
    http = WinHttpOpen(L"DeliveryCheck/0.2", WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY, NULL, NULL, 0);
    if (!http) goto done;
    WinHttpSetTimeouts(http, 15000, 15000, 30000, 30000);
    conn = WinHttpConnect(http, host, INTERNET_DEFAULT_HTTPS_PORT, 0); if (!conn) goto done;
    request = WinHttpOpenRequest(conn, L"GET", resource, NULL, NULL, NULL, WINHTTP_FLAG_SECURE); if (!request) goto done;
    if (!WinHttpSendRequest(request, NULL, 0, NULL, 0, 0, 0) || !WinHttpReceiveResponse(request, NULL)) goto done;
    if (!WinHttpQueryHeaders(request, WINHTTP_QUERY_STATUS_CODE|WINHTTP_QUERY_FLAG_NUMBER, NULL, &code, &length, NULL) || code != 200) goto done;
    length = sizeof(total); WinHttpQueryHeaders(request, WINHTTP_QUERY_CONTENT_LENGTH|WINHTTP_QUERY_FLAG_NUMBER, NULL, &total, &length, NULL);
    file = CreateFileW(partial, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL); if (file == INVALID_HANDLE_VALUE) goto done;
    while (!cancelled) {
        if (!WinHttpReadData(request, buffer, sizeof(buffer), &got)) goto done;
        if (!got) break;
        received += got; if (received > 250ULL*1024*1024) goto done;
        if (!WriteFile(file, buffer, got, &wrote, NULL) || got != wrote) goto done;
        int percentage = total ? (int)(received*100/total) : 0;
        if (percentage != last) {
            wchar_t message[256]; swprintf(message, 256, L"Downloading %ls: %d%%", name, percentage);
            status(message, base+percentage*span/100); last = percentage;
        }
    }
    if (cancelled || (total && received != total)) goto done;
    CloseHandle(file); file = INVALID_HANDLE_VALUE;
    if (!hash_matches(partial, checksum)) {log_line(L"Archive checksum did not match. Nothing from it was installed."); goto done;}
    ok = MoveFileExW(partial, dest, MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH) != 0;
done:
    if (!ok) {wchar_t msg[128]; swprintf(msg, 128, L"Download failed. HTTP %lu, Windows error %lu", code, GetLastError()); log_line(msg);}
    if (file != INVALID_HANDLE_VALUE) CloseHandle(file);
    if (request) WinHttpCloseHandle(request);
    if (conn) WinHttpCloseHandle(conn);
    if (http) WinHttpCloseHandle(http);
    if (!ok) DeleteFileW(partial);
    return ok;
}

static HANDLE spawn(const wchar_t *exe, const wchar_t *arguments, const wchar_t *cwd, const wchar_t *log) {
    wchar_t command[16000];
    if (swprintf(command, 16000, L"\"%ls\" %ls", exe, arguments) < 0) return NULL;
    SECURITY_ATTRIBUTES sa = {sizeof(sa), NULL, TRUE};
    HANDLE output = CreateFileW(log, FILE_APPEND_DATA, FILE_SHARE_READ|FILE_SHARE_WRITE, &sa, OPEN_ALWAYS, 0, NULL);
    HANDLE input = CreateFileW(L"NUL", GENERIC_READ, FILE_SHARE_READ|FILE_SHARE_WRITE, &sa, OPEN_EXISTING, 0, NULL);
    if (output == INVALID_HANDLE_VALUE || input == INVALID_HANDLE_VALUE) {
        if (output != INVALID_HANDLE_VALUE) CloseHandle(output);
        if (input != INVALID_HANDLE_VALUE) CloseHandle(input);
        return NULL;
    }
    STARTUPINFOW si = {0}; PROCESS_INFORMATION pi = {0}; si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES|STARTF_USESHOWWINDOW; si.wShowWindow = SW_HIDE;
    si.hStdOutput = output; si.hStdError = output; si.hStdInput = input;
    int ok = CreateProcessW(exe, command, NULL, NULL, TRUE, CREATE_NO_WINDOW, NULL, cwd, &si, &pi);
    CloseHandle(output); CloseHandle(input);
    if (!ok) return NULL;
    CloseHandle(pi.hThread); return pi.hProcess;
}
static int run(const wchar_t *exe, const wchar_t *args, DWORD timeout) {
    HANDLE p = spawn(exe, args, root, log_path); if (!p) return 0;
    ULONGLONG until = GetTickCount64()+timeout; DWORD code = 1;
    while (WaitForSingleObject(p, 100) == WAIT_TIMEOUT) {
        if (cancelled || GetTickCount64()>until) {TerminateProcess(p, 1); WaitForSingleObject(p, 5000); break;}
    }
    GetExitCodeProcess(p, &code); CloseHandle(p); return code == 0 && !cancelled;
}
static void ps_literal(const wchar_t *source, wchar_t *dest) {
    *dest++ = L'\'';
    while (*source) { if (*source==L'\'') *dest++=L'\''; *dest++=*source++; }
    *dest++ = L'\''; *dest = 0;
}
static int expand(const wchar_t *zip, const wchar_t *dest) {
    wchar_t sys[CAP], exe[CAP], z[CAP*2+3], d[CAP*2+3], args[12000];
    if (!GetSystemDirectoryW(sys, CAP)) return 0;
    path_join(exe, sys, L"WindowsPowerShell\\v1.0\\powershell.exe");
    ps_literal(zip, z); ps_literal(dest, d);
    swprintf(args, 12000, L"-NoProfile -NonInteractive -WindowStyle Hidden -Command \"$ErrorActionPreference='Stop'; Expand-Archive -LiteralPath %ls -DestinationPath %ls -Force\"", z, d);
    return run(exe, args, 180000);
}

static int json_string(const char *json, const char *key, char *out, size_t cap) {
    char needle[64]; snprintf(needle, sizeof(needle), "\"%s\"", key);
    const char *p=strstr(json, needle); if (!p) return 0;
    p=strchr(p, ':'); if (!p) return 0; p++;
    while (*p==' ') p++; if (*p++!='"') return 0;
    const char *end=strchr(p, '"'); if (!end || (size_t)(end-p)>=cap) return 0;
    memcpy(out, p, (size_t)(end-p)); out[end-p]=0; return 1;
}
static int live_session(wchar_t *url) {
    FILE *fp = _wfopen(session_path, L"rb"); if (!fp) return 0;
    char json[2048], address[256], token[128]; size_t n=fread(json,1,sizeof(json)-1,fp); fclose(fp); json[n]=0;
    if (!json_string(json,"url",address,sizeof(address)) || !json_string(json,"token",token,sizeof(token))) return 0;
    const char *prefix="http://127.0.0.1:";
    if (strncmp(address,prefix,strlen(prefix))) return 0;
    char *end; long port=strtol(address+strlen(prefix), &end, 10);
    if (*end || port<1 || port>65535) return 0;
    for (const char *p=token; *p; ++p) if (!((*p>='A'&&*p<='Z')||(*p>='a'&&*p<='z')||(*p>='0'&&*p<='9')||*p=='_'||*p=='-')) return 0;
    HINTERNET http=WinHttpOpen(L"DeliveryCheck/0.2",WINHTTP_ACCESS_TYPE_NO_PROXY,NULL,NULL,0);
    if (!http) return 0;
    WinHttpSetTimeouts(http,700,700,700,700);
    HINTERNET conn=WinHttpConnect(http,L"127.0.0.1",(INTERNET_PORT)port,0);
    HINTERNET req=conn?WinHttpOpenRequest(conn,L"GET",L"/api/health",NULL,NULL,NULL,0):NULL;
    wchar_t header[256], wide_token[128]; MultiByteToWideChar(CP_UTF8,0,token,-1,wide_token,128);
    swprintf(header,256,L"X-DeliveryCheck-Token: %ls\r\n",wide_token);
    int ok=0; DWORD code=0,length=sizeof(code),got=0; char body[4096]={0};
    if (req && WinHttpSendRequest(req,header,(DWORD)-1,NULL,0,0,0) && WinHttpReceiveResponse(req,NULL)
        && WinHttpQueryHeaders(req,WINHTTP_QUERY_STATUS_CODE|WINHTTP_QUERY_FLAG_NUMBER,NULL,&code,&length,NULL) && code==200) {
        size_t offset=0;
        while (offset<sizeof(body)-1 && WinHttpReadData(req,body+offset,(DWORD)(sizeof(body)-1-offset),&got) && got) offset+=got;
        char application[64];
        ok=json_string(body,"application",application,sizeof(application)) && !strcmp(application,"DeliveryCheck") && strstr(body,"\"ready\": true");
    }
    if (req) WinHttpCloseHandle(req); if (conn) WinHttpCloseHandle(conn); WinHttpCloseHandle(http);
    if (ok) MultiByteToWideChar(CP_UTF8,0,address,-1,url,256);
    return ok;
}

static int install_and_open(void) {
    wchar_t url[256]={0};
    stage(L"Checking for your open workspace...",3);
    if (live_session(url)) return (INT_PTR)ShellExecuteW(NULL,L"open",url,NULL,NULL,SW_SHOWNORMAL)>32;
    wchar_t downloads[CAP], app[CAP], app_zip_path[CAP], app_file[CAP], marker[CAP];
    wchar_t py_dir[CAP], python[CAP], pyzip[CAP], pth[CAP], ff_dir[CAP], ffzip[CAP], ffbin[CAP], ffmpeg[CAP], ffprobe[CAP];
    path_join(downloads,root,L"downloads"); path_join(app,root,APP_FOLDER);
    path_join(app_zip_path,downloads,L"app.zip"); path_join(app_file,app,L"app.py"); path_join(marker,app,L"install.complete");
    path_join(py_dir,root,L"python-3.13.16"); path_join(python,py_dir,L"python.exe"); path_join(pyzip,downloads,L"python-3.13.16.zip"); path_join(pth,py_dir,L"python313._pth");
    path_join(ff_dir,root,L"ffmpeg-8.1.2"); path_join(ffzip,downloads,L"ffmpeg-8.1.2.zip"); path_join(ffbin,ff_dir,L"ffmpeg-8.1.2-essentials_build\\bin");
    path_join(ffmpeg,ffbin,L"ffmpeg.exe"); path_join(ffprobe,ffbin,L"ffprobe.exe");
    if (!directory(downloads)||!directory(app)||!directory(py_dir)||!directory(ff_dir)) return 0;
    ULARGE_INTEGER free_space; if (GetDiskFreeSpaceExW(root,&free_space,NULL,NULL) && free_space.QuadPart<800ULL*1024*1024) {stage(L"Setup needs at least 800 MB of free disk space.",0); return 0;}
    if (!exists(marker)||!exists(app_file)) {
        stage(L"Installing DeliveryCheck...",8);
        if (!write_bytes(app_zip_path,app_zip,app_zip_len)||!expand(app_zip_path,app)||!exists(app_file)||!write_bytes(marker,"complete",8)) return 0;
        DeleteFileW(app_zip_path);
    }
    wchar_t pth_text[CAP+64]; swprintf(pth_text,CAP+64,L"python313.zip\n.\n%ls\n",app);
    /* Always repair _pth, including after an interrupted installation. */
    if (!write_utf8(pth,pth_text)) return 0;
    stage(L"Checking the private Python runtime...",14);
    if (!exists(python)||!run(python,L"-X utf8 -c \"import engine, http.server, ssl; print('Python ready')\"",15000)) {
        stage(L"Installing Python. First launch needs internet access...",18);
        if (!download(L"www.python.org",L"/ftp/python/3.13.16/python-3.13.16-embed-amd64.zip",pyzip,"97dae5274cc54867065e8d5a3226e48c35017ed332a0fdb0e27d5b5821961297",L"Python",18,15)
            || !expand(pyzip,py_dir) || !write_utf8(pth,pth_text)
            || !run(python,L"-X utf8 -c \"import engine, http.server, ssl; print('Python ready')\"",15000)) return 0;
    }
    stage(L"Checking the private video engine...",36);
    if (!exists(ffmpeg)||!exists(ffprobe)||!run(ffmpeg,L"-version",15000)||!run(ffprobe,L"-version",15000)) {
        stage(L"Installing the video engine. Download is about 105 MB...",38);
        if (!download(L"www.gyan.dev",L"/ffmpeg/builds/packages/ffmpeg-8.1.2-essentials_build.zip",ffzip,"db580001caa24ac104c8cb856cd113a87b0a443f7bdf47d8c12b1d740584a2ec",L"video engine",38,40)
            || !expand(ffzip,ff_dir) || !run(ffmpeg,L"-version",15000)||!run(ffprobe,L"-version",15000)) return 0;
    }
    if (cancelled) return 0;
    stage(L"Starting your local workspace...",90);
    wchar_t args[CAP*2+128], app_log[CAP]; path_join(app_log,root,L"app.log");
    swprintf(args,_countof(args),L"-X utf8 \"%ls\" --no-browser --session-file \"%ls\"",app_file,session_path);
    SetEnvironmentVariableW(L"DELIVERYCHECK_FFMPEG_DIR",ffbin);
    HANDLE process=spawn(python,args,app,app_log); if (!process) return 0;
    int ready=0;
    for (int i=0;i<100 && !cancelled;i++) {
        if (WaitForSingleObject(process,0)==WAIT_OBJECT_0) break;
        if (live_session(url)) {ready=1;break;}
        Sleep(250);
    }
    if (!ready) {TerminateProcess(process,1);WaitForSingleObject(process,5000);CloseHandle(process);return 0;}
    CloseHandle(process);
    stage(L"Opening DeliveryCheck in your browser...",100);
    if ((INT_PTR)ShellExecuteW(NULL,L"open",url,NULL,NULL,SW_SHOWNORMAL)<=32) {log_line(url);return 0;}
    return 1;
}

static DWORD WINAPI worker(LPVOID unused) {
    (void)unused;
    DWORD lock_result = WaitForSingleObject(setup_lock,0);
    if (lock_result != WAIT_OBJECT_0 && lock_result != WAIT_ABANDONED) {
        stage(L"Another DeliveryCheck setup is running. Wait for it to finish, then retry.",0);
        PostMessageW(window,WM_DONE,0,0); return 0;
    }
    int ok=install_and_open();
    if (!ok) {wchar_t detail[384];swprintf(detail,384,L"Stopped during: %ls (Windows error %lu)",current_stage,GetLastError());log_line(detail);}
    ReleaseMutex(setup_lock); PostMessageW(window,WM_DONE,ok,0); return 0;
}
static void start_worker(void) {
    cancelled=0;working=1;ShowWindow(retry_button,SW_HIDE);ShowWindow(folder_button,SW_HIDE);SetWindowTextW(close_button,L"Cancel");
    HANDLE thread=CreateThread(NULL,0,worker,NULL,0,NULL);
    if (thread) CloseHandle(thread); else PostMessageW(window,WM_DONE,0,0);
}
static LRESULT CALLBACK window_proc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch(msg) {
        case WM_STATUS: SetWindowTextW(label,(wchar_t*)lp);SendMessageW(progress,PBM_SETPOS,wp,0);free((void*)lp);return 0;
        case WM_DONE:
            working=0;
            if (wp||cancelled) {DestroyWindow(hwnd);return 0;}
            SetWindowTextW(close_button,L"Close");ShowWindow(retry_button,SW_SHOW);ShowWindow(folder_button,SW_SHOW);
            {wchar_t msg_text[600];swprintf(msg_text,600,L"Setup could not finish.\n%ls\nCheck your connection and select Retry. Details are in setup.log.",current_stage);SetWindowTextW(label,msg_text);}
            return 0;
        case WM_COMMAND:
            if (LOWORD(wp)==ID_RETRY && !working) start_worker();
            if (LOWORD(wp)==ID_FOLDER) ShellExecuteW(NULL,L"open",root,NULL,NULL,SW_SHOWNORMAL);
            if (LOWORD(wp)==ID_CLOSE) SendMessageW(hwnd,WM_CLOSE,0,0);
            return 0;
        case WM_CLOSE:
            if (working) {InterlockedExchange(&cancelled,1);SetWindowTextW(label,L"Cancelling setup. Waiting for the current operation to stop...");return 0;}
            DestroyWindow(hwnd);return 0;
        case WM_DESTROY: PostQuitMessage(0);return 0;
        default: return DefWindowProcW(hwnd,msg,wp,lp);
    }
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE previous,PWSTR command,int show) {
    (void)previous;(void)command;(void)show;
    wchar_t local[CAP];DWORD size=GetEnvironmentVariableW(L"LOCALAPPDATA",local,CAP);
    if (!size||size>CAP-100) return 1;
    path_join(root,local,L"DeliveryCheck");if(!directory(root)){MessageBoxW(NULL,L"The local app folder could not be created.",L"DeliveryCheck",MB_OK|MB_ICONERROR);return 1;}
    path_join(log_path,root,L"setup.log");path_join(session_path,root,L"session.json");
    uint32_t hash=2166136261u;for(const wchar_t *p=root;*p;p++){hash^=(uint32_t)*p;hash*=16777619u;}
    wchar_t mutex_name[100];swprintf(mutex_name,100,L"Local\\DeliveryCheckSetup_%08x",hash);
    setup_lock=CreateMutexW(NULL,FALSE,mutex_name);if(!setup_lock)return 1;
    SetProcessDPIAware();INITCOMMONCONTROLSEX ic={sizeof(ic),ICC_PROGRESS_CLASS};InitCommonControlsEx(&ic);
    WNDCLASSW wc={0};wc.lpfnWndProc=window_proc;wc.hInstance=instance;wc.hCursor=LoadCursorW(NULL,IDC_ARROW);wc.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);wc.lpszClassName=L"DeliveryCheckSetup";RegisterClassW(&wc);
    window=CreateWindowExW(0,wc.lpszClassName,L"DeliveryCheck | Setup and launch",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU,(GetSystemMetrics(SM_CXSCREEN)-580)/2,(GetSystemMetrics(SM_CYSCREEN)-300)/2,580,300,NULL,NULL,instance,NULL);
    if(!window)return 1;
    font=CreateFontW(-16,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");
    label=CreateWindowW(L"STATIC",L"Preparing DeliveryCheck...",WS_CHILD|WS_VISIBLE,26,28,520,100,window,NULL,instance,NULL);
    progress=CreateWindowW(PROGRESS_CLASSW,L"",WS_CHILD|WS_VISIBLE,26,141,516,18,window,NULL,instance,NULL);
    retry_button=CreateWindowW(L"BUTTON",L"Retry",WS_CHILD|BS_DEFPUSHBUTTON,26,193,95,32,window,(HMENU)ID_RETRY,instance,NULL);
    folder_button=CreateWindowW(L"BUTTON",L"Open logs",WS_CHILD,135,193,120,32,window,(HMENU)ID_FOLDER,instance,NULL);
    close_button=CreateWindowW(L"BUTTON",L"Cancel",WS_CHILD|WS_VISIBLE,445,193,95,32,window,(HMENU)ID_CLOSE,instance,NULL);
    HWND controls[]={label,retry_button,folder_button,close_button};for(int i=0;i<4;i++)SendMessageW(controls[i],WM_SETFONT,(WPARAM)font,TRUE);
    SendMessageW(progress,PBM_SETRANGE,0,MAKELPARAM(0,100));ShowWindow(window,SW_SHOW);start_worker();
    MSG msg;while(GetMessageW(&msg,NULL,0,0)>0){TranslateMessage(&msg);DispatchMessageW(&msg);}
    DeleteObject(font);CloseHandle(setup_lock);return 0;
}
