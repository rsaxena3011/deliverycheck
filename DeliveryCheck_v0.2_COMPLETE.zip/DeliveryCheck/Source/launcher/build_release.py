"""Build a Windows GUI launcher and one complete buyer ZIP.

Requires Python 3.10+ and Zig 0.16.0. No downloaded runtimes are redistributed.
Run from any directory: python launcher/build_release.py --zig /path/to/zig
"""
import argparse
import hashlib
import io
from pathlib import Path
import struct
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
APP = ROOT if (ROOT / 'app.py').exists() else ROOT / 'deliverycheck'
BUILD = HERE / 'build'
EXCLUDES = {'__pycache__', '.DS_Store', 'SHA256SUMS.txt', 'CONTENTS.txt',
            'Run_Windows.cmd', 'Run_Linux.sh', 'Run_macOS.command'}


def app_files():
    return [(p.relative_to(APP).as_posix(), p.read_bytes()) for p in sorted(APP.rglob('*'))
            if p.is_file() and not set(p.parts).intersection(EXCLUDES)]


def zip_bytes(items):
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in items:
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 6, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            z.writestr(info, data)
    return stream.getvalue()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--zig', default='zig')
    args = parser.parse_args()
    BUILD.mkdir(exist_ok=True)
    files = app_files()
    payload = zip_bytes(files)
    digest = hashlib.sha256(payload).hexdigest()
    (BUILD / 'app_payload.zip').write_bytes(payload)
    header = '#define APP_FOLDER L"app-0.2.0-' + digest[:12] + '"\n'
    header += 'static const unsigned char app_zip[] = {\n'
    header += '\n'.join(','.join(str(x) for x in payload[i:i+32])+',' for i in range(0,len(payload),32))
    header += '\n};\nstatic const unsigned int app_zip_len = sizeof(app_zip);\n'
    (HERE / 'app_bundle.h').write_text(header, encoding='ascii')
    exe = BUILD / 'DeliveryCheck.exe'
    subprocess.run([args.zig, 'cc', str(HERE / 'DeliveryCheckLauncher.c'),
                    '-target', 'x86_64-windows-gnu', '-O2', '-s', '-Wall', '-Wextra',
                    '-Werror', '-municode', '-Wl,--subsystem,windows', '-o', str(exe),
                    '-lcomctl32', '-lshell32', '-lwinhttp', '-lbcrypt', '-lole32', '-lgdi32'], check=True)
    binary = exe.read_bytes()
    pe = struct.unpack_from('<I', binary, 0x3c)[0]
    assert binary[:2] == b'MZ' and binary[pe:pe+4] == b'PE\0\0'
    assert struct.unpack_from('<H', binary, pe+4)[0] == 0x8664
    assert struct.unpack_from('<H', binary, pe+24+68)[0] == 2, 'Must be GUI subsystem'
    guide = (APP / 'START_HERE.html').read_text(encoding='utf-8')
    guide = guide.replace('href="demo/', 'href="Source/demo/').replace('src="demo/../docs/', 'src="Source/docs/')
    items = [('DeliveryCheck.exe', binary), ('START_HERE.html', guide.encode('utf-8')),
             ('README.md', (APP/'README.md').read_bytes()), ('LICENSE.txt', (APP/'LICENSE.txt').read_bytes()),
             ('THIRD_PARTY_NOTICES.md', (APP/'THIRD_PARTY_NOTICES.md').read_bytes())]
    items += [('Source/'+name, data) for name,data in files]
    items += [('Source/launcher/'+p.name,p.read_bytes()) for p in (HERE/'DeliveryCheckLauncher.c',HERE/'build_release.py')]
    if (HERE/'BUILD_NOTES.md').exists(): items.append(('Source/launcher/BUILD_NOTES.md',(HERE/'BUILD_NOTES.md').read_bytes()))
    hashes = ''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in items)
    items.append(('SHA256SUMS.txt',hashes.encode('utf-8')))
    package = zip_bytes([('DeliveryCheck/'+name,data) for name,data in items])
    output = ROOT/'output'/'DeliveryCheck_v0.2_COMPLETE.zip'
    output.parent.mkdir(exist_ok=True)
    output.write_bytes(package)
    with zipfile.ZipFile(output) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(set(z.namelist()))
    print(f'Built {output} ({len(package):,} bytes, {len(items)} files)')
    print('SHA256 '+hashlib.sha256(package).hexdigest())


if __name__ == '__main__':
    main()
