# Windows build

DeliveryCheck.exe is a Windows x64 GUI bootstrap. The buyer double-clicks it.

To rebuild as a developer, install Zig 0.16.0 and Python 3.10 or newer, then run the included build_release.py with --zig pointing to the Zig executable. The script accepts the original repository structure or the delivered Source/launcher structure.

The build embeds the current app, demo media and guide. It creates an app folder whose name includes a payload hash, so a later build does not overwrite a running copy. Runtime archives are downloaded directly from their publishers and are not inside the buyer ZIP.

The launcher uses WinHTTP with normal certificate validation. It downloads to a partial file, verifies a pinned SHA256 digest, then installs. ZIP extraction uses the installed Windows PowerShell Expand-Archive command. It does not change execution policies. Managed computers that block PowerShell may prevent setup; the user sees Retry and Open logs controls.

Python and both video executables are checked before the app starts. The launcher repairs an incomplete runtime installation and always writes the embedded Python search path. It uses explicit UTF-8 and the Windows wide-character APIs for user paths. FFmpeg is located through a child-process environment variable, without editing system PATH.

Only one setup runs per user. Existing sessions are checked through their authenticated loopback health endpoint. A successful launch opens one browser tab. Reopening restores the active project and its current report.

Validation completed here: both publisher archives were downloaded and their hashes and layouts verified; the launcher compiled with warnings treated as errors; the output is PE32+ x64 with the Windows GUI subsystem; engine and Chromium workflow checks passed.

Native Windows execution was not available in this environment. Compilation and static inspection do not replace a Windows smoke test. Code signing, native Windows 10/11 first-launch and repair tests, and larger production-media trials remain release checks before a public commercial launch.
