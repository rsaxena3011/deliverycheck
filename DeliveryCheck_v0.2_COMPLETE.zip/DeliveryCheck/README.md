# DeliveryCheck 0.2.0

DeliveryCheck is a local video delivery checker for freelance editors and small agencies.

## Windows launch

In the complete buyer ZIP, double-click **DeliveryCheck.exe**. It automatically installs a private copy of Python and FFmpeg inside your user profile, verifies both downloads, starts the local checker and opens it in your browser. No Command Prompt, package manager, Python install or FFmpeg install is required.

The first launch needs an internet connection for the private runtimes. Later launches reuse the installed files. The launcher does not change your system PATH and does not require administrator access. Double-clicking it again opens the existing session instead of starting a duplicate.

The launcher targets Windows 10 and Windows 11 x64. It is unsigned. The app and browser checks passed on Linux; native Windows execution remains to be verified. The precise test coverage is recorded in Source/docs/TEST_REPORT.md.

## First run

1. Double-click **DeliveryCheck.exe**.
2. Click **Try the sample project** to see a known test delivery, or click **Upload videos** for your own exports.
3. Optionally set a **Delivery list** when filenames and technical specifications matter.
4. Click **Run check**.
5. Select a file and click a finding timestamp to inspect the exact moment.
6. Export an HTML, CSV or JSON report when you are finished.

The sample contains four synthetic videos, one missing expected deliverable, six technical errors and three review alerts. It is included to make the first run understandable.

## Your own delivery

Add files by drag and drop, the Upload videos button or the Add a folder button. Selected files are staged in a temporary local folder. Originals are never edited. A New project action clears the current staged files and results from the session while optionally keeping the delivery list and settings.

The optional delivery list supports exact filenames, display dimensions, duration, average frame rate, video codec and whether audio must exist. Names are matched without case sensitivity. A language code is a filename label, not verified speech. A quick scan without a delivery list checks media anomalies but cannot verify completeness against a brief.

## What the checks mean

- **Technical errors:** missing or ambiguous deliverables, incorrect required metadata, missing required audio, corrupt or incomplete analysis. Fix these and rerun the check.
- **Review alerts:** near-black intervals, low-motion intervals, quiet audio, peaks above the chosen limit, loudness outside an optional target, additional tracks or unlisted files. An intentional alert can be accepted with an explanation.
- **Checked:** no outstanding errors or alerts within this scan scope. It is not a certification of every aspect of a video.

The engine decodes the first video and first audio tracks across the full duration. Creative quality, spelling, spoken language, safe areas, subtitles, A/V synchronization, HDR mastering and platform policy compliance remain outside this version's scope.

## Local files and reports

The browser communicates only with the local checker. Media is not uploaded to a cloud service. Normal shutdown removes temporary staged copies. Export reports before closing if you need to keep the current result. Reports preserve settings, requirements, findings and review decisions, but do not contain the media.

Closing a browser tab keeps the local app running. Reopen DeliveryCheck.exe to resume the current files and results. Use **Quit** in the app to end the session. Export your report before quitting; past sessions do not reopen after the app has stopped.

The included **Source** folder is for inspection and development. The buyer workflow is the single Windows executable at the top level of the ZIP. The first setup downloads about 116 MB and needs at least 800 MB of free space, plus room for local copies of your videos. Scans support up to 500 files and 8 GB per file.
